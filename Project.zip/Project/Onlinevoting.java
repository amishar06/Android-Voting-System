import java.util.Scanner;

public class Onlinevoting{

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int NumCan, NumStu, i, j, Vote, max;
        String[] CanName = new String[11];
        int[] VoteFor = new int[11];
        String[] id = new String[101];
        String pass;

        System.out.println("                     Online Voting System / CR Election System                   ");
        System.out.println("                     _________________________________________                   ");
        System.out.println("                        :::::::::: ADMIN PANEL ::::::::::");
        System.out.println("=================================================================================");
        System.out.println();
        System.out.println();
        System.out.print("    Number of Candidate: ");
        NumCan = scanner.nextInt();
        if (NumCan > 1) {
            for (i = 1; i <= NumCan; i++) {
                System.out.print("    Candidate-" + i + " Name: ");
                CanName[i] = scanner.next();
                VoteFor[i] = 0;
            }
            System.out.print("    Number of Voters: ");
            NumStu = scanner.nextInt();
            System.out.println("  Thank You Admin! we are going to start our election with " + NumStu + " Students and " + NumCan + " Candidates.");
            System.out.println();
            System.out.println();
            System.out.println("=================================================================================");
            System.out.println();
            System.out.println();

            System.out.print("                            Enter The Password: ");
            pass = scanner.next();
            while (!pass.equals("mypass")) {
                System.out.println();
                System.out.println("                            Wrong Password! Try Again.");
                System.out.println();
                System.out.print("                       Enter The Correct Password: ");
                pass = scanner.next();
                System.out.println();
            }

            for (i = 1; i <= NumStu; i++) {
                System.out.println("                     Online Voting System / CR Election System                   ");
                System.out.println("                     _________________________________________                   ");
                System.out.println("                        :::::::::: VOTING PANEL ::::::::::");
                System.out.println("                                   Student - " + i);
                System.out.println("=================================================================================");
                System.out.println();

                System.out.println("                             Enter Your ID: ");
                id[i] = scanner.next();
                int c = 0;
                for (int k = 1; k <= 100; k++) {
                    if (id[i].equals(id[k])) {
                        c = k;
                        System.out.println("                                    Data found");
                        System.out.println();
                        System.out.println("    ID: " + id[i]);
                        break;
                    }
                }

                System.out.println("                  ===========================================");
                System.out.println();
                System.out.println();
                for (j = 1; j <= NumCan; j++) {
                    System.out.println("                              Press " + j + " For " + CanName[j]);
                }
                System.out.println();
                System.out.println("                  ===========================================");
                System.out.print("    Now, Please Put Your Vote: ");
                Vote = scanner.nextInt();
                System.out.println("(Hidden)");

                // Code for storing votes and processing results can be added here

                System.out.println();
                System.out.println();
                System.out.println("                  Thanks " + id[i] + " For Your Vote.(Press Enter for Next)");
                System.out.println();
                System.out.println();
                System.out.println("=================================================================================");
                scanner.nextLine(); // Consume newline left after nextInt
            }

            System.out.println("                     Online Voting System / CR Election System                   ");
            System.out.println("                     _________________________________________                   ");
            System.out.println("                        :::::::::: RESULT PANEL ::::::::::");
            System.out.println("=================================================================================");
            System.out.println();
            System.out.print("                            Enter The Password: ");
            pass = scanner.next();
            while (!pass.equals("gu2023@")) {
                System.out.println();
                System.out.println("                            Wrong Password! Try Again.");
                System.out.println();
                System.out.print("                       Enter The Correct Password: ");
                pass = scanner.next();
                System.out.println();
            }

            System.out.println("                  ===========================================");
            for (j = 1; j <= NumCan; j++) {
                System.out.println("                              " + CanName[j] + " Get " + VoteFor[j] + " Vote.");
            }
            System.out.println();
            System.out.println("                  ===========================================");
            max = 0;
            for (j = 1; j <= NumCan; j++) {
                if (max < VoteFor[j]) {
                    max = VoteFor[j];
                }
            }
            for (j = 1; j <= NumCan; j++) {
                if (max == VoteFor[j]) {
                    System.out.println();
                    System.out.println("           Congratulations " + CanName[j] + ". You are Elected as our new CR.");
                    break;
                }
            }
            System.out.println();
            System.out.println("=================================================================================");
        } else {
            System.out.println("Sorry! Number of Candidate must be more than one person.");
        }
    }
}
